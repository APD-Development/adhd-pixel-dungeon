Unaccepted new Meditate fixture initially used Sungrass remainingPool method for Healing. Corrected to existing Healing.remainingHealingPool; product source compiled. No mechanics changed.
